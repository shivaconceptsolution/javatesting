package scs;

public class ConsDemo2 extends ConsDemo1 {
	 ConsDemo2()
	   {
		   super();
		   System.out.println("ConsDemo2");
	   }
	 
	 public static void main(String args[])
	 {
		 ConsDemo2 obj = new ConsDemo2();
		 
	 }

}
