package scs;

public class AccessCompanyInfo {

	public static void main(String[] args) {
		
		Client obj1 = new Client();
		
		obj1.accept1("Client1","Indore");
	
		obj1.display1();
		
		

	}

}
