package scs;

public class Addition {
   int a,b,c;
   void accept(int a,int b)
   {
	   this.a=a;
	   this.b=b;
   }
   void add()
   {
	   c=a+b;
   }
   void display()
   {
	   System.out.println(c);
   }
}
