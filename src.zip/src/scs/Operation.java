package scs;

public class Operation {

	public static void main(String[] args) {
		Addition o = new Addition();
		o.accept(10, 2);
		o.add();
		o.display();
		Substraction o1 = new Substraction();
		o1.accept(100, 20);
		o1.sub();
		o1.display();
	}

}
