package scs;

public class Substraction extends Addition {
	void sub()
	{
		c=a-b;
	}

}
