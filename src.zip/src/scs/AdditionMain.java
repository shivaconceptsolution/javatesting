package scs;

public class AdditionMain {

	public static void main(String[] args) {
		AdditionExample obj = new AdditionExample();
		obj.addition(12.34,11.67);

	}

}
