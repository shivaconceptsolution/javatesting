package scs;

public class Billing {
  String productname;
  int qty;
  int price;
  float total;
   void accept(String productname,int qty,int price)
   {
	  this.productname = productname;
	  this.qty = qty;
	  this.price = price;
	   
   }
   
   void bill()
   {
	   total = price*qty;
   }
   
   void displayBill()
   {
	   System.out.println("Product name is "+productname);
	   System.out.println("Bill is "+total);
	   
   }
}
