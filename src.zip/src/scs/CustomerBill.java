package scs;

public class CustomerBill {

	public static void main(String[] args) {
		Billing obj = new Billing();
		obj.accept("p1", 2, 1200);
		obj.bill();
		obj.displayBill();
		BillingNew obj1 = new BillingNew();
		obj1.accept("p1", 2, 1200);
		obj1.bill();
		obj1.displayBill(); 

	}

}
