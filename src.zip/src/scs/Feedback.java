package scs;

public class Feedback extends Company {
  private String feedmsg;
  void accept2(String feedmsg)
  {
	  this.feedmsg=feedmsg;
  }
  void display2()
  {
	  System.out.println("Feedback Message is "+feedmsg);
  }
}
