package scs;

public class Company {
   private int companyid;
   private String companyname;
   void accept(int companyid,String companyname)
   {
	   this.companyid = companyid;
	   this.companyname = companyname;
	   
   }
   
   void display()
   {
	   System.out.println("Company id is "+companyid);
	   System.out.println("Company name is "+companyname);
	   
   }
   
}
