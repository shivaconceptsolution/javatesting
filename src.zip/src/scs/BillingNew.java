package scs;

public class BillingNew extends Billing {
	void bill()
	   {
		   total = price*qty + (price*qty)* 0.18F;
	   }
}
