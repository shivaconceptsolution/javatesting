package scs;

public class Customer {

	public static void main(String[] args) {
		Bank obj = new Bank();
		obj.login(1123);

	}

}
