package scs;

public class ConsDemo1 {
   ConsDemo1()
   {
	   System.out.println("ConsDemo1");
   }
}
