package scs;

public class AccessProperty {

	public static void main(String[] args) {
		EncapsulationExample obj = new EncapsulationExample();
		obj.setRno(1001);
		System.out.println(obj.getRno());
		

	}

}
