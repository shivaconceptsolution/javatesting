package scs;

public class Client extends Company{

	private String clientname;
	private String address;
	void accept1(String clientname,String address)
	{
		super.accept(1001, "ABC");
		this.clientname = clientname;
		this.address = address;
	}
	void display1()
	{
		super.display();
		System.out.println("Client Name is "+clientname);
		System.out.println("Client Address is "+address);
	}
}
