package scs;

public class AdditionExample {
	   void addition(int a, int b)
	    {
          System.out.println(a+b);
	    }
	   
	    void addition(int a, double b)
	    {
	    	System.out.println(a+b);
	    }
	    void addition(double a, int b)
	    {
	    	System.out.println(a+b);
	    }
	    void addition(double a, double b)
	    {
	    	System.out.println("add double");
	    	System.out.println(a+b);

	    }

}
