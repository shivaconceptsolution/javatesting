package inhr;

public class Area {

	public static void main(String[] args) {
		Rectangle obj = new Rectangle();
		obj.accept(10);
		obj.accept1(20);
		obj.reactArea();
		obj.display();

	}

}
