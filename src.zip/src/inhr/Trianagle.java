package inhr;

public class Trianagle extends Circle {
	int b;
	void accept1(int b)
	{
		this.b=b;
	}
   
    void triangeArea()
    {
	    area = (a*b)/2;
    }
}
