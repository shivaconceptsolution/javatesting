package inhr;

public class Rectangle extends Trianagle {
   void reactArea()
   {
	   area = a*b;
   }
}
