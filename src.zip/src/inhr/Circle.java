package inhr;

public class Circle {
  int a;
  float area;
  void accept(int a)
  {
	  this.a=a;
  }
  void circleArea()
  {
	  area = 3.14F*a*a;
  }
  void display()
  {
	  System.out.println("Area is "+area);
  }
}
