package branch2;
import branch1.A;
public class B {

	public static void main(String[] args) {
		A obj = new A();
		obj.fun4();

	}

}
