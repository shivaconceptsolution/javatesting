package branch2;
import branch1.A;
public class C extends A {

	public static void main(String[] args) {
		C obj = new C();
		obj.fun3();
		obj.fun4();

	}

}
