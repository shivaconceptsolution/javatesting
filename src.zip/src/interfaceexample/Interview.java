package interfaceexample;

interface Interview {
	void practice();
    void communication();
    void hardwork();
    void smartwork();
}
