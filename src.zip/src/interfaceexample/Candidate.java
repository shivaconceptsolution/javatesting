package interfaceexample;

public class Candidate implements Interview,Criteria {

	@Override
	public void practice() {
		
		System.out.println("Minimum practice time 4hrs-8hrs");
	}

	@Override
	public void communication() {
		System.out.println("good communication skills");
		
	}

	@Override
	public void hardwork() {
		System.out.println("work per day basis");
		
	}

	@Override
	public void smartwork() {
		System.out.println("improve logics");
		
	}

	@Override
	public void minimumCriteria() {
		// TODO Auto-generated method stub
		
	}

}
