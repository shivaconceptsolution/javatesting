package interfaceexample;

public interface Criteria {
   void minimumCriteria();
} 
