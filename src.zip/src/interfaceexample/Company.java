package interfaceexample;

public class Company {

	public static void main(String[] args) {
		Candidate obj = new Candidate();
		obj.communication();
		
	}

}
