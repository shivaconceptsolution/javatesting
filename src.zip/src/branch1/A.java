package branch1;

public class A {
    private void fun1()
    {
    	System.out.println("Private");
    }
    void fun2()
    {
    	System.out.println("Default");
    }
    
    protected void fun3()
    {
    	System.out.println("Protected");
    }
    
    public void fun4()
    {
    	System.out.println("Public");
    }
}
