package branch1;

public class AAccess {

	public static void main(String[] args) {
		A obj = new A();
		obj.fun2();
		obj.fun3();
		obj.fun4();

	}

}
